# Austria qualifying fails deleted-lap integrity review

Lewis Hamilton's crash caused the first Q3 red flag and George Russell's caused the second, but the official result and lap feed also disagree over Sergio Pérez's Q2 and Q3 running.

## At a Glance

- VER took pole with an official Q3 time of 1:04.984.
- S1 made the largest contribution to the pole margin, worth 0.070 seconds to VER; the other sectors combined for -0.041 seconds of the 0.029-second margin.
- Q3 pole: LEC was 0.029 seconds behind VER; Q1 advancement cutoff: RIC was 0.024 seconds behind GAS; Q2 advancement cutoff: ALB was 0.070 seconds behind GAS

## Session Context

Hamilton crashed at Turn 7 to cause the first Q3 red flag; after the restart, Russell crashed at the final corner and stopped the session again.

## How Qualifying Unfolded

Running best laps on session time show when the competitive order changed through Q1, Q2 and Q3.

VER took pole with an official Q3 time of 1:04.984.

## Pole and Cutoff Battles

The official same-segment margins separate the pole fight from the Q1 and Q2 advancement battles.

Q3 pole: LEC was 0.029 seconds behind VER; Q1 advancement cutoff: RIC was 0.024 seconds behind GAS; Q2 advancement cutoff: ALB was 0.070 seconds behind GAS

## Sector Comparison

The sector split identifies where the official pole margin was won rather than stopping at the arithmetic.

S1 made the largest contribution to the pole margin, worth 0.070 seconds to VER; the other sectors combined for -0.041 seconds of the 0.029-second margin.

![Horizontal bars show how each sector contributed to the lap-time difference between pole position and second place.](charts/chart-2d619548e6/qualifying_sector_contribution-b1422813.png)

*Signed sector contributions to the official Q3 pole margin.*

## Conclusion

Hamilton and Russell's crashes repeatedly reset the Q3 contest; the Pérez deletion conflict still blocks analytical publication.

## Methods and Evidence

- Complete recorded sectors from the selected valid Q3 laps; signed deltas reconcile within 0.003 seconds.
- Official Q1/Q2/Q3 segment order, advancement outcomes, and final session classification.
- Official within-segment best times; advancement boundaries follow the official outcome before time arithmetic.

## Provenance

- Publication policy: `qualifying-publication-selection` v4
- Publication export contract: v3
- Editorial source: https://www.formula1.com/en/results/2022/races/1115/austria/qualifying
- Editorial source: https://www.formula1.com/en/latest/article/verstappen-beats-ferraris-to-pole-in-austria-as-both-mercedes-crash-out-of.gwiQsXrDwuXn1ZgRALzWy.gwiQsXrDwuXn1ZgRALzWy
