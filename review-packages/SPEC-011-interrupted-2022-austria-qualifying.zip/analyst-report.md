# 2022 Austria Qualifying Report

_Deterministic factual draft for human editorial review._

## Executive Summary

- VER took pole with an official Q3 time of 1:04.984.
  - Confidence: `high`
- Hamilton crashed at Turn 7 to cause the first Q3 red flag; after the restart, Russell crashed at the final corner and stopped the session again.
  - Confidence: `high`
- Q3 pole: LEC was 0.029 seconds behind VER; Q1 advancement cutoff: RIC was 0.024 seconds behind GAS; Q2 advancement cutoff: ALB was 0.070 seconds behind GAS
  - Confidence: `high`

## Session Context

- Hamilton crashed at Turn 7 to cause the first Q3 red flag; after the restart, Russell crashed at the final corner and stopped the session again.
  - Confidence: `high`

## How Qualifying Unfolded

- VER took pole with an official Q3 time of 1:04.984.
  - Confidence: `high`

## Pole and Cutoff Battles

- Q3 pole: LEC was 0.029 seconds behind VER; Q1 advancement cutoff: RIC was 0.024 seconds behind GAS; Q2 advancement cutoff: ALB was 0.070 seconds behind GAS
  - Confidence: `high`

## Sector Comparison

- S1 made the largest contribution to the pole margin, worth 0.070 seconds to VER; the other sectors combined for -0.041 seconds of the 0.029-second margin.
  - Confidence: `high`

![Qualifying Sector Contribution](charts/chart-2d619548e6/qualifying_sector_contribution-b1422813.png)
[Chart metadata](charts/chart-2d619548e6/qualifying_sector_contribution-b1422813.json)

## Limitations and Evidence

- Qualifying temporal evolution context only: The qualifying context remains independently inspectable but is not promoted automatically.
- Qualifying conditions context only: The recorded context was not material enough to define the session story.
- Qualifying deleted laps not reportable: Official qualifying results conflict with lap-level validity or deletion evidence.
- Qualifying attempt progression not reportable: Official qualifying results conflict with lap-level validity or deletion evidence.

## Provenance

- Publication policy: `qualifying-publication-selection` v4
- Publication export contract: v3
- Editorial source: https://www.formula1.com/en/results/2022/races/1115/austria/qualifying
- Editorial source: https://www.formula1.com/en/latest/article/verstappen-beats-ferraris-to-pole-in-austria-as-both-mercedes-crash-out-of.gwiQsXrDwuXn1ZgRALzWy.gwiQsXrDwuXn1ZgRALzWy

---

Report schema: `1`  
Evidence fingerprint: `6f43c1c7f7ca959d8d962320c488314a3abbcc3ace2e8f2d5d510f6fd8f5e4e1`
