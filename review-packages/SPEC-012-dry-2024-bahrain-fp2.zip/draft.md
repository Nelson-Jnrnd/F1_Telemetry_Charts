# Bahrain FP2 reveals comparable observed long-run samples

Official order remains unavailable from the configured source, while paired recorded tyre ages support bounded same-compound long-run observations.

## Relevant Runs

Pit-bounded runs retain representative and excluded laps, compound evidence, coverage, and unknown programme limitations.

ALO Run 4 recorded a long run of 10 representative laps on SOFT, with a median of 1:37.390. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Horizontal bars show representative Practice lap-time interquartile ranges with a median marker for each eligible driver run.](charts/chart-49cbacd56d/practice_long_run_pace_summary-212490db.png)

*Representative-lap medians and interquartile ranges with sample and tyre-age coverage retained in evidence.*

## Matched Long-Run Comparison

Only overlapping same-compound samples paired at reliable shared tyre ages expose a scalar observed difference.

Across 12 paired SOFT tyre-age samples, LEC Run 4 was 1.331 seconds faster than ZHO Run 5 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

## Observed Run Trend

The fitted line describes observed within-run pace evolution without assigning fuel, tyre, traffic, or programme cause.

TSU Run 3 showed an observed +2.122-second change from the fitted start to end on the stint progress basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Scatter points show representative Practice lap times by run progress with dashed non-causal fitted trend lines.](charts/chart-e5930b7add/practice_observed_pace_evolution-dd23e580.png)

*Representative laps and fitted observed run-progress trends; hidden programme variables remain unknown.*

## Conclusion

The observed long-run samples are comparable on their recorded basis, while fuel load and programme variables remain unknown.

## Methods and Evidence

- Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
- Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
- Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.

## Provenance

- Publication policy: `practice-publication-selection` v1
- Publication export contract: v3
