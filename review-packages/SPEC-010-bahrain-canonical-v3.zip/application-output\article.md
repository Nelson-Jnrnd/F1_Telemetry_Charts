# Verstappen wins in Bahrain as Gasly leads the recovery

Max Verstappen led Sergio Perez and Fernando Alonso home in Bahrain, while Pierre Gasly made the race's largest field recovery and the selected pace evidence compared the leading Red Bulls.

## At a Glance

- Verstappen won ahead of Perez and Alonso.
- Gasly made the largest field recovery.
- The race included a Virtual Safety Car period.

## How the Race Developed

Verstappen headed Perez and Alonso at the finish, Gasly gained ten places, and a Virtual Safety Car marked the neutralised phase.

Max Verstappen won ahead of Sergio Perez and Fernando Alonso. Pierre Gasly made the largest field recovery, gaining 10 places from grid to finish. A Virtual Safety Car period ran from laps 40 to 42.

## Pace and Strategy

The following comparisons use representative laps for Verstappen and Perez; they do not measure the elapsed race gap.

VER's stint 1 representative median was 0.663 s/lap lower than PER's (11 versus 14 representative laps).

Across the representative-lap comparison, VER accumulated an 11.134-second pace advantage over PER between laps 3 and 57; this is a derived pace total, not the elapsed race gap.

![Line chart of representative Soft-tyre lap times across the opening stints: VER's solid-circle trace remains below PER's dashed-square trace, with excluded laps in a separate strip.](assets/chart-d636662958/stint_pace-d4cfbf87.png)

*Verstappen held the lower representative median lap time in the compared opening stints.*

![Broken line chart of derived cumulative VER-versus-PER pace delta by race lap, trending downward with a shaded VSC band across laps 40 to 42.](assets/chart-590557042c/race_time_delta_evolution-efd02cb6.png)

*The derived accumulation shows Verstappen's representative-lap pace advantage over Perez; it is not the elapsed race gap.*

## Key Comparison

VER's observed representative lap time increased by 0.066 seconds per stint-progress lap, versus 0.026 for PER; a 0.040 s/lap steeper increase for VER.

![Scatter plot of representative lap time against stint-progress lap for VER and PER, with separate upward fitted lines; VER's fit rises more steeply.](assets/chart-d5c663f76c/pace_evolution-191295d5.png)

*Verstappen's representative lap times increased more steeply than Perez's across the compared opening stints.*

## Conclusion

Bahrain's reviewed evidence combines the podium, Gasly's recovery and the leading Red Bulls' representative-lap pace without assigning strategy intent.

## Methods and Evidence

- VER stint 1, laps 1-14 vs PER stint 1, laps 1-17; representative laps only.
- VER vs PER, laps 3-57; derived cumulative representative-lap pace difference, not elapsed race gap.
