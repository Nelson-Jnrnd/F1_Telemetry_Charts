# SPEC-010 Bahrain Canonical Package — Export Contract v3

This is the accepted Bahrain dry-race package with the post-acceptance portable
evidence-reference cleanup. The article, editorial selection, claim placement
and selected charts are unchanged.

In `application-output/evidence.json`:

- selected exported chart evidence uses `reference_scope: package` and paths
  under `assets/` that resolve within this directory;
- non-selected analytical provenance uses `reference_scope: source_analysis`
  and explicit `source_image_path` / `source_metadata_path` fields;
- source-analysis references do not expose ambiguous `image_path` or
  `metadata_path` fields.

The application created this export under publication export contract version
3. Files in `application-output/` were copied from that application export
without editing.
