# Verstappen wins Bahrain pole in the first sector

Max Verstappen beat Charles Leclerc by 0.228 seconds, with almost the entire pole margin established in the opening sector.

## At a Glance

- VER took pole with an official Q3 time of 1:29.179.
- VER secured pole in S1, gaining 0.227 seconds there; LEC was essentially level across the other two sectors combined (+0.001 seconds).
- Q3 pole: LEC was 0.228 seconds behind VER; Q2 advancement cutoff: TSU was 0.007 seconds behind PIA

## How Qualifying Unfolded

Running best laps on session time show when the competitive order changed through Q1, Q2 and Q3.

VER took pole with an official Q3 time of 1:29.179. Q1: VER held the benchmark before SAI lowered it to 1:29.909 at 25.1 minutes; Q2: VER held the benchmark before LEC lowered it to 1:29.165 at 53.5 minutes; Q3: RUS held the benchmark before VER lowered it to 1:29.179 at 74.1 minutes.

![Three qualifying panels chart running best lap times against session time, with tyre markers and shaded rain or red-flag periods.](assets/chart-c0ff7f3c45/qualifying_progression-28e0ab87.png)

*Running best laps on session time, with compound markers, the competitive benchmark and recorded red-flag periods.*

## Pole and Cutoff Battles

The official same-segment margins separate the pole fight from the Q1 and Q2 advancement battles.

Q3 pole: LEC was 0.228 seconds behind VER; Q2 advancement cutoff: TSU was 0.007 seconds behind PIA

## Sector Comparison

The sector split identifies where the official pole margin was won rather than stopping at the arithmetic.

VER secured pole in S1, gaining 0.227 seconds there; LEC was essentially level across the other two sectors combined (+0.001 seconds).

![Horizontal bars show how each sector contributed to the lap-time difference between pole position and second place.](assets/chart-5e5d796908/qualifying_sector_contribution-969d5f88.png)

*Signed sector contributions to the official Q3 pole margin.*

## Conclusion

Verstappen's first-sector advantage decided pole; Leclerc was effectively level over the remaining two sectors.

## Methods and Evidence

- Complete recorded sectors from the selected valid Q3 laps; signed deltas reconcile within 0.003 seconds.
- Official Q1/Q2/Q3 segment order, advancement outcomes, and final session classification.
- Official within-segment best times; advancement boundaries follow the official outcome before time arithmetic.
- Source-assigned qualifying segments; only valid, non-deleted timed laps update each driver's recorded best.

## Provenance

- Publication policy: `qualifying-publication-selection` v4
- Publication export contract: v3
- Editorial source: https://www.formula1.com/en/results/2024/races/1229/bahrain/qualifying
