# Recorded stoppages shape the Netherlands FP2 evidence

Session-control timing and excluded laps preserve the interruption boundaries without assigning team intent or reconstructing hidden programme variables.

## Session Context

Recorded weather and session-control evidence establish the condition and interruption boundaries for this Practice session.

Recorded session control shows 1 Practice interruption state changes affecting approximately 726 seconds.

## Relevant Runs

Pit-bounded runs retain representative and excluded laps, compound evidence, coverage, and unknown programme limitations.

RUS Run 4 recorded a long run of 9 representative laps on SOFT, with a median of 1:16.721. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Horizontal bars show representative Practice lap-time interquartile ranges with a median marker for each eligible driver run.](charts/chart-b9cc588d3b/practice_long_run_pace_summary-8775d9e5.png)

*Representative-lap medians and interquartile ranges with sample and tyre-age coverage retained in evidence.*

## Matched Long-Run Comparison

Only overlapping same-compound samples paired at reliable shared tyre ages expose a scalar observed difference.

Across 8 paired HARD tyre-age samples, ALO Run 4 was 1.590 seconds faster than HUL Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

## Observed Run Trend

The fitted line describes observed within-run pace evolution without assigning fuel, tyre, traffic, or programme cause.

MAG Run 3 showed an observed +2.053-second change from the fitted start to end on the stint progress basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Scatter points show representative Practice lap times by run progress with dashed non-causal fitted trend lines.](charts/chart-86831a3611/practice_observed_pace_evolution-61fd1909.png)

*Representative laps and fitted observed run-progress trends; hidden programme variables remain unknown.*

## Conclusion

The interruption-aware samples remain useful evidence, but they do not establish a controlled competitive ranking or predict the weekend outcome.

## Methods and Evidence

- Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
- Recorded session-control timing.
- Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
- Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.

## Provenance

- Publication policy: `practice-publication-selection` v1
- Publication export contract: v3
