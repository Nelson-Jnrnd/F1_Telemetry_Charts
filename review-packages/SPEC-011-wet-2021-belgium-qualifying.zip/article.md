# Verstappen denies Russell after Norris crash resets wet Spa qualifying

Norris topped Q1 and Q2 before crashing without a Q3 time; after the long red flag, Russell briefly took provisional pole before Verstappen beat him by 0.321 seconds.

## At a Glance

- VER took pole with an official Q3 time of 1:59.765.
- Conditions and stoppages defined the qualifying sequence. Qualifying opened on full wets before the field moved to intermediates; Q3 returned to full wets before later intermediate running. A 42-minute Q3 red flag split the segment before the restart.
- RUS gained 0.257 seconds in S1; VER recovered 0.269 seconds in S2 and another 0.309 seconds in S3 to take pole by 0.321 seconds.
- Q3 pole: RUS was 0.321 seconds behind VER

## Session Context

Qualifying began on full wets before the improving circuit brought intermediates into play. Rain intensified for Q3, Norris crashed before setting a time, and the long red flag preceded an intermediate-tyre restart in which Russell briefly held provisional pole before Verstappen beat him by 0.321 seconds.

## How Qualifying Unfolded

Running best laps on session time show when the competitive order changed through Q1, Q2 and Q3.

VER took pole with an official Q3 time of 1:59.765. Q1: VER held the benchmark before NOR lowered it to 1:58.301 at 45.3 minutes; Q2: VER held the benchmark before NOR lowered it to 1:56.025 at 67.7 minutes; Q3: RUS held the benchmark before VER lowered it to 1:59.765 at 130.3 minutes.

![Three qualifying panels chart running best lap times against session time, with tyre markers and shaded rain or red-flag periods.](assets/chart-e66f22c1a5/qualifying_progression-c79f0ad0.png)

*Running best laps on session time, with compound markers, the competitive benchmark and recorded red-flag periods.*

## Pole and Cutoff Battles

The official same-segment margins separate the pole fight from the Q1 and Q2 advancement battles.

Q3 pole: RUS was 0.321 seconds behind VER

## Sector Comparison

The sector split identifies where the official pole margin was won rather than stopping at the arithmetic.

RUS gained 0.257 seconds in S1; VER recovered 0.269 seconds in S2 and another 0.309 seconds in S3 to take pole by 0.321 seconds.

![Horizontal bars show how each sector contributed to the lap-time difference between pole position and second place.](assets/chart-d6eb86c8ed/qualifying_sector_contribution-45dc293c.png)

*Signed sector contributions to the official Q3 pole margin.*

## Conclusion

Wet-track evolution and Norris's interruption reset Q3, then Russell's provisional pole forced Verstappen to deliver the decisive final lap.

## Methods and Evidence

- Complete recorded sectors from the selected valid Q3 laps; signed deltas reconcile within 0.003 seconds.
- Official Q1/Q2/Q3 segment order, advancement outcomes, and final session classification.
- Official within-segment best times; advancement boundaries follow the official outcome before time arithmetic.
- Source-assigned qualifying segments; only valid, non-deleted timed laps update each driver's recorded best.

## Provenance

- Publication policy: `qualifying-publication-selection` v4
- Publication export contract: v3
- Editorial source: https://www.formula1.com/en/latest/article/qualifying-verstappen-denies-russell-shock-pole-in-dramatic-wet-qualifying.XP92uMlcsG9ZQbF0vpqYn
- Editorial source: https://www.formula1.com/en/latest/article/norris-cleared-to-race-in-belgian-grand-prix-after-high-speed-crash-in.6YgE5dp9k71zm36LXRSeux.6YgE5dp9k71zm36LXRSeux
