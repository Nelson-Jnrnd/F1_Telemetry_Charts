# Wet Suzuka running limits direct long-run comparison

Recorded rain and wet-compound evidence keep incompatible Practice samples descriptive and prevent an unsupported scalar competitive ranking.

## Session Context

Recorded weather and session-control evidence establish the condition and interruption boundaries for this Practice session.

Recorded Practice conditions were wet or mixed; compounds observed: INTERMEDIATE, WET.

## Relevant Runs

Pit-bounded runs retain representative and excluded laps, compound evidence, coverage, and unknown programme limitations.

PER Run 5 recorded a long run of 11 representative laps on INTERMEDIATE, with a median of 1:47.128. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Horizontal bars show representative Practice lap-time interquartile ranges with a median marker for each eligible driver run.](charts/chart-4faf9ce684/practice_long_run_pace_summary-a4d3a78f.png)

*Representative-lap medians and interquartile ranges with sample and tyre-age coverage retained in evidence.*

## Matched Long-Run Comparison

Only overlapping same-compound samples paired at reliable shared tyre ages expose a scalar observed difference.

Across 10 paired INTERMEDIATE tyre-age samples, STR Run 3 was 1.698 seconds slower than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

## Observed Run Trend

The fitted line describes observed within-run pace evolution without assigning fuel, tyre, traffic, or programme cause.

TSU Run 4 showed an observed +1.970-second change from the fitted start to end on the tyre age basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.

![Scatter points show representative Practice lap times by run progress with dashed non-causal fitted trend lines.](charts/chart-ae8161ac0f/practice_observed_pace_evolution-dba87b44.png)

*Representative laps and fitted observed run-progress trends; hidden programme variables remain unknown.*

## Conclusion

The wet-session evidence describes only the recorded samples and does not assign a cause to observed pace evolution.

## Methods and Evidence

- Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
- Recorded weather and compound evidence.
- Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
- Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.

## Provenance

- Publication policy: `practice-publication-selection` v1
- Publication export contract: v3
