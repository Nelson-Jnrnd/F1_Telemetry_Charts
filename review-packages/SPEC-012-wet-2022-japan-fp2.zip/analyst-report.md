# 2022 Japan Practice Report

_Deterministic factual draft for human editorial review._

## Executive Summary

- Recorded Practice conditions were wet or mixed; compounds observed: INTERMEDIATE, WET.
  - Confidence: `high`
- Across 10 paired INTERMEDIATE tyre-age samples, STR Run 3 was 1.698 seconds slower than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 9 paired INTERMEDIATE tyre-age samples, PER Run 5 was 0.482 seconds faster than VER Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.

## Session Context

- Recorded Practice conditions were wet or mixed; compounds observed: INTERMEDIATE, WET.
  - Confidence: `high`
  - Basis: Recorded weather and compound evidence.

## Relevant Runs

- STR Run 3 recorded a long run of 10 representative laps on INTERMEDIATE, with a median of 1:49.001. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. Observed lap times are not fuel-corrected and do not establish competitive order.
- VER Run 3 recorded a long run of 13 representative laps on INTERMEDIATE, with a median of 1:46.909. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. Observed lap times are not fuel-corrected and do not establish competitive order.
- PER Run 5 recorded a long run of 11 representative laps on INTERMEDIATE, with a median of 1:47.128. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. Observed lap times are not fuel-corrected and do not establish competitive order.
- VET Run 3 recorded a long run of 11 representative laps on INTERMEDIATE, with a median of 1:46.980. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. Observed lap times are not fuel-corrected and do not establish competitive order.
- TSU Run 4 recorded a long run of 13 representative laps on INTERMEDIATE, with a median of 1:48.016. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Pit-bounded representative laps; type-7 median and quantiles with 10% symmetric trimming.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. Observed lap times are not fuel-corrected and do not establish competitive order.

![Practice Long-Run Pace Summary](charts/chart-4faf9ce684/practice_long_run_pace_summary-a4d3a78f.png)
[Chart metadata](charts/chart-4faf9ce684/practice_long_run_pace_summary-a4d3a78f.json)

## Matched Long-Run Comparison

- Across 10 paired INTERMEDIATE tyre-age samples, STR Run 3 was 1.698 seconds slower than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 9 paired INTERMEDIATE tyre-age samples, PER Run 5 was 0.482 seconds faster than VER Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 9 paired INTERMEDIATE tyre-age samples, PER Run 5 was 1.653 seconds faster than TSU Run 4 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 10 paired INTERMEDIATE tyre-age samples, STR Run 3 was 1.149 seconds slower than TSU Run 4 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 11 paired INTERMEDIATE tyre-age samples, TSU Run 4 was 0.523 seconds slower than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 11 paired INTERMEDIATE tyre-age samples, VER Run 3 was 0.151 seconds faster than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 10 paired INTERMEDIATE tyre-age samples, STR Run 3 was 1.441 seconds slower than VER Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 8 paired INTERMEDIATE tyre-age samples, PER Run 5 was 0.931 seconds faster than VET Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.
- Across 13 paired INTERMEDIATE tyre-age samples, TSU Run 4 was 0.998 seconds slower than VER Run 3 by the paired median. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Same-compound overlapping runs paired at at least eight shared reliable recorded tyre ages.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. This is an observed-sample comparison, not a fuel-corrected ranking.

## Observed Run Trend

- TSU Run 4 showed an observed +1.970-second change from the fitted start to end on the stint progress basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.
- PER Run 5 showed an observed +2.300-second change from the fitted start to end on the tyre age basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `medium`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.
- TSU Run 4 showed an observed +1.970-second change from the fitted start to end on the tyre age basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.
- VER Run 3 showed an observed +1.291-second change from the fitted start to end on the tyre age basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.
- VER Run 3 showed an observed +1.291-second change from the fitted start to end on the stint progress basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `high`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.
- PER Run 5 showed an observed +2.300-second change from the fitted start to end on the stint progress basis. Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown.
  - Confidence: `medium`
  - Basis: Theil-Sen observed pace evolution on one explicit run-progress or tyre-age basis; no causal interpretation.
  - Limitations: Fuel load, engine mode, setup, tyre preparation, and programme intent are unknown. The fitted slope is observed pace evolution, not causal tyre degradation.

![Practice Observed Pace Evolution](charts/chart-ae8161ac0f/practice_observed_pace_evolution-dba87b44.png)
[Chart metadata](charts/chart-ae8161ac0f/practice_observed_pace_evolution-dba87b44.json)

## Limitations and Evidence

- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice classification unavailable: The analytical result is unavailable; no claim was generated.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run comparison context only: Unknown or confounded run comparability exposes no publishable scalar.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice interruptions context only: The independently owned Practice context is inspectable but not material.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice run chronology context only: The Practice evidence remains inspectable but is not promoted automatically.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice long run pace context only: Sustained or low-coverage running remains evidence-only.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.
- Practice observed pace evolution context only: The fit does not meet the long-run sample and quality publication threshold.

## Provenance

- Publication policy: `practice-publication-selection` v1
- Publication export contract: v3

---

Report schema: `1`  
Evidence fingerprint: `551d8a6fc21aa955f27b5e944a48e3013f5af438a6f18c3039f616835a2dd99b`
